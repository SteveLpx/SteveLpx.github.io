The icons bundled with this application are using icons bundled primarily
with the Mist icon theme. These icons are licensed under the
LGPL version 2.1. The assests for the Mist icon theme, bundled in with
the full gnome-themes package, can be found
at http://ftp.gnome.org/pub/GNOME/sources/gnome-themes/.
The full text of the LGPL version 2.1 license can be read in the
included lgpl-2.1.txt file.

Any icons not bundled with Mist are from the Oxygen icon theme. Those icons
are licensed under the LGPL version 3. The full text of the LGPL version 3
license can be read in the included lgpl-3.0.txt file. The full Oxygen icon
theme can be downloaded from
http://download.kde.org/stable/4.10.2/src/oxygen-icons-4.10.2.tar.xz.
Additionally, you can got the Oxygen theme website located at
http://www.oxygen-icons.org/.